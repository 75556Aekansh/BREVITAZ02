package com.example.fire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FireApplicationTests {

	@Test
	void contextLoads() {
	}

}
