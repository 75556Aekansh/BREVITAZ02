package com.example.fire.service;

import com.example.fire.model.Project;

import java.util.List;

public interface ProjectService {
    List<Project> getAllProjects();
    Project getProjectById(Long id);
    Project saveProject(Project project);
    void deleteProject(Long id);
}
