package com.example.fire.controller;

import com.example.fire.dto.ProjectDTO;
import com.example.fire.model.Project;
import com.example.fire.service.ProjectService;
import com.example.fire.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/projects")
public class ProjectController {
    @Autowired
    private ProjectService projectService;

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public List<ProjectDTO> getAllProjects() {
        return projectService.getAllProjects().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ProjectDTO getProjectById(@PathVariable Long id) {
        return convertToDTO(projectService.getProjectById(id));
    }

    @PostMapping
    public ProjectDTO createProject(@RequestBody ProjectDTO projectDTO) {
        Project project = convertToEntity(projectDTO);
        return convertToDTO(projectService.saveProject(project));
    }

    @PutMapping("/{id}")
    public ProjectDTO updateProject(@PathVariable Long id, @RequestBody ProjectDTO projectDTO) {
        Project project = convertToEntity(projectDTO);
        project.setProjectId(id);
        return convertToDTO(projectService.saveProject(project));
    }

    @DeleteMapping("/{id}")
    public void deleteProject(@PathVariable Long id) {
        projectService.deleteProject(id);
    }

    private ProjectDTO convertToDTO(Project project) {
        ProjectDTO projectDTO = new ProjectDTO();
        projectDTO.setProjectId(project.getProjectId());
        projectDTO.setProjectName(project.getProjectName());
        projectDTO.setProjectDescription(project.getProjectDescription());
        projectDTO.setEmployeeIds(project.getEmployees().stream().map(employee -> employee.getId()).collect(Collectors.toSet()));
        return projectDTO;
    }

    private Project convertToEntity(ProjectDTO projectDTO) {
        Project project = new Project();
        project.setProjectName(projectDTO.getProjectName());
        project.setProjectDescription(projectDTO.getProjectDescription());
        if (projectDTO.getEmployeeIds() != null) {
            project.setEmployees(projectDTO.getEmployeeIds().stream().map(employeeService::getEmployeeById).collect(Collectors.toSet()));
        }
        return project;
    }
}
