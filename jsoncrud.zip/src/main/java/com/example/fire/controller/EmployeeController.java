package com.example.fire.controller;

import com.example.fire.dto.*;
import com.example.fire.model.Employee;
import com.example.fire.model.Department;
import com.example.fire.model.Project;
import com.example.fire.model.Task;
import com.example.fire.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/basic/{id}")
    public EmployeeBasicDTO getBasicEmployeeById(@PathVariable Long id) {
        Employee employee = employeeService.getEmployeeById(id);
        return convertToBasicDTO(employee);
    }

    @GetMapping
    public List<EmployeeDTO> getAllEmployees() {
        return employeeService.getAllEmployees().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public EmployeeDTO getEmployeeById(@PathVariable Long id) {
        return convertToDTO(employeeService.getEmployeeById(id));
    }

    @PostMapping
    public EmployeeDTO createEmployee(@RequestBody EmployeeDTO employeeDTO) {
        Employee employee = convertToEntity(employeeDTO);
        return convertToDTO(employeeService.saveEmployee(employee));
    }

    @PutMapping("/{id}")
    public EmployeeDTO updateEmployee(@PathVariable Long id, @RequestBody EmployeeDTO employeeDTO) {
        Employee employee = convertToEntity(employeeDTO);
        employee.setId(id);
        return convertToDTO(employeeService.saveEmployee(employee));
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
    }

    private EmployeeDTO convertToDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        employeeDTO.setId(employee.getId());
        employeeDTO.setFirstName(employee.getFirstName());
        employeeDTO.setLastName(employee.getLastName());
        employeeDTO.setEmail(employee.getEmail());

        if (employee.getDepartment() != null) {
            DepartmentDTO departmentDTO = new DepartmentDTO();
            departmentDTO.setDeptId(employee.getDepartment().getDeptId());
            departmentDTO.setDeptName(employee.getDepartment().getDeptName());
            departmentDTO.setDeptDesc(employee.getDepartment().getDeptDesc());
            employeeDTO.setDepartment(departmentDTO);
        }

        if (employee.getProjects() != null) {
            Set<ProjectDTO> projectDTOs = employee.getProjects().stream().map(project -> {
                ProjectDTO projectDTO = new ProjectDTO();
                projectDTO.setProjectId(project.getProjectId());
                projectDTO.setProjectName(project.getProjectName());
                projectDTO.setProjectDescription(project.getProjectDescription());
                return projectDTO;
            }).collect(Collectors.toSet());
            employeeDTO.setProjects(projectDTOs);
        }

        if (employee.getTasks() != null) {
            Set<TaskDTO> taskDTOs = employee.getTasks().stream().map(task -> {
                TaskDTO taskDTO = new TaskDTO();
                taskDTO.setTaskId(task.getTaskId());
                taskDTO.setTaskName(task.getTaskName());
                taskDTO.setTaskDesc(task.getTaskDesc());
                return taskDTO;
            }).collect(Collectors.toSet());
            employeeDTO.setTasks(taskDTOs);
        }
        return employeeDTO;
    }

    private Employee convertToEntity(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        employee.setFirstName(employeeDTO.getFirstName());
        employee.setLastName(employeeDTO.getLastName());
        employee.setEmail(employeeDTO.getEmail());

        if (employeeDTO.getDepartment() != null) {
            Department department = new Department();
            department.setDeptId(employeeDTO.getDepartment().getDeptId());
            department.setDeptName(employeeDTO.getDepartment().getDeptName());
            department.setDeptDesc(employeeDTO.getDepartment().getDeptDesc());
            employee.setDepartment(department);
        }

        if (employeeDTO.getProjects() != null) {
            Set<Project> projects = employeeDTO.getProjects().stream().map(projectDTO -> {
                Project project = new Project();
                project.setProjectId(projectDTO.getProjectId());
                project.setProjectName(projectDTO.getProjectName());
                project.setProjectDescription(projectDTO.getProjectDescription());
                return project;
            }).collect(Collectors.toSet());
            employee.setProjects(projects);
        }

        if (employeeDTO.getTasks() != null) {
            Set<Task> tasks = employeeDTO.getTasks().stream().map(taskDTO -> {
                Task task = new Task();
                task.setTaskId(taskDTO.getTaskId());
                task.setTaskName(taskDTO.getTaskName());
                task.setTaskDesc(taskDTO.getTaskDesc());
                return task;
            }).collect(Collectors.toSet());
            employee.setTasks(tasks);
        }
        return employee;
    }

    private EmployeeBasicDTO convertToBasicDTO(Employee employee) {
        EmployeeBasicDTO employeeBasicDTO = new EmployeeBasicDTO();
        employeeBasicDTO.setId(employee.getId());
        employeeBasicDTO.setFirstName(employee.getFirstName());
        employeeBasicDTO.setLastName(employee.getLastName());
        employeeBasicDTO.setEmail(employee.getEmail());
        return employeeBasicDTO;
    }
}
