package com.example.fire.controller;

import com.example.fire.dto.TaskDTO;
import com.example.fire.model.Task;
import com.example.fire.service.TaskService;
import com.example.fire.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    @Autowired
    private TaskService taskService;

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public List<TaskDTO> getAllTasks() {
        return taskService.getAllTasks().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public TaskDTO getTaskById(@PathVariable Long id) {
        return convertToDTO(taskService.getTaskById(id));
    }

    @PostMapping
    public TaskDTO createTask(@RequestBody TaskDTO taskDTO) {
        Task task = convertToEntity(taskDTO);
        return convertToDTO(taskService.saveTask(task));
    }

    @PutMapping("/{id}")
    public TaskDTO updateTask(@PathVariable Long id, @RequestBody TaskDTO taskDTO) {                          //@Requestbody annotaion is used to convert the json into the  object for taskDTO
        Task task = convertToEntity(taskDTO);
        task.setTaskId(id);
        return convertToDTO(taskService.saveTask(task));
    }

    @DeleteMapping("/{id}")
    public void deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
    }

    private TaskDTO convertToDTO(Task task) {
        TaskDTO taskDTO = new TaskDTO();
        taskDTO.setTaskId(task.getTaskId());
        taskDTO.setTaskName(task.getTaskName());
        taskDTO.setTaskDesc(task.getTaskDesc());
        taskDTO.setEmployeeIds(task.getEmployee() != null ? task.getEmployee().getId() : null);
        return taskDTO;
    }

    private Task convertToEntity(TaskDTO taskDTO) {
        Task task = new Task();
        task.setTaskName(taskDTO.getTaskName());
        task.setTaskDesc(taskDTO.getTaskDesc());
        if (taskDTO.getEmployeeIds() != null) {
            task.setEmployee(employeeService.getEmployeeById(taskDTO.getEmployeeIds()));
        }
        return task;
    }
}