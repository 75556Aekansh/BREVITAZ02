package com.example.fire.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;

public class ProjectDTO {
    private Long projectId;
    private String projectName;
    private String projectDescription;
    @JsonIgnore
    private Set<Long> employeeIds;


    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public Set<Long> getEmployeeIds() {
        return employeeIds;
    }

    public void setEmployeeIds(Set<Long> employeeIds) {
        this.employeeIds = employeeIds;
    }
}
