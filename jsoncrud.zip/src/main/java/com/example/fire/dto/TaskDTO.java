package com.example.fire.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;

public class TaskDTO {
    private Long taskId;
    private String taskName;
    private String taskDesc;

    @JsonIgnore
    private Long employeeIds;

    public Long getTaskId() {
        return taskId;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    public void setTaskDesc(String taskDesc) {
        this.taskDesc = taskDesc;
    }

    public Long getEmployeeIds() {
        return employeeIds;
    }

    public void setEmployeeIds(Long employeeIds) {
        this.employeeIds = employeeIds;
    }

}
